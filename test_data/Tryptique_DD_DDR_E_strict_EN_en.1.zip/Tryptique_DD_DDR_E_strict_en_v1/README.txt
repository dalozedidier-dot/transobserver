DD / DD-R / EQUILIBRIUM E TRIPTYCH — separated package

Scope:
- refs/ : reference documents (Epistemological Rules, Glossary, Frameworks DD/DD-R/E)
- docs/ : technical complements (formulas / clarifications)

Separation rule:
- This package does not include the "Protocol" folder.
- The "Protocol" folder (OSF / method repository) must reference this triptych as an external dependency, with no internal duplication.

Package version: en.1

Files added at root (English interface layer):
- INDEX.txt
- PROTOCOL_LINKING.txt
- CHANGELOG.txt
- VERSION.txt
- MANIFEST_SHA256.json

French originals are preserved under fr_original/ (unchanged, for auditability).
