# A structure
- Item A1
- Item A2
- Item A3

```python
- should_not_count_1
- should_not_count_2
```

# B métrologie
- Item B1
- Item B2
