Notes:
- Dossier minimal. Aucun service externe requis.
- Les sorties reposent sur la série proxy (IDs 1..n).
