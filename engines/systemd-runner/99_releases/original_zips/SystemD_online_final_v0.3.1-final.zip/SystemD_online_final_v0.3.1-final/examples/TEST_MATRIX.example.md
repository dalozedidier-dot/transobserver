# TEST_MATRIX.md (template)

## Règles globales
- R-01 exemple
- R-02 exemple
- R-03 exemple
- R-04 exemple

## Conventions sorties
- O-01 exemple
- O-02 exemple
- O-03 exemple

## A — Tests structure
- A-01 exemple
- A-02 exemple
- A-03 exemple
- A-04 exemple

## B — Métrologie
- B-01 exemple
- B-02 exemple
- B-03 exemple
