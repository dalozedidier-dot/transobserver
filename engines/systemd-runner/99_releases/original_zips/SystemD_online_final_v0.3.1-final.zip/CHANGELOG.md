# CHANGELOG

## v0.3.1
- Parsing: ignore fenced code blocks, Unicode normalization for headings.
- Add strict parsing mode and warnings in extraction report.
- Optimize quantile computation (single sort).
- Add --verbose and summary field.
- Add internal unit tests (--run-tests).

## v0.3.1-final
- Spécification: paramètres globaux explicites (eps, min_n_for_moments/quantiles/MAD).
- Unicode normalization: procédure déterministe (NFC → casefold → NFKD → strip Mn → collapse spaces).
- Parsing: règles d’arrêt déterministes (strict-parsing sur unassigned > 0 ; max-unassigned-ratio indépendant).
- Reporting: ajout `summary_humain` (strictement descriptif) + `neutralized_by_min_n_for_moments`.
- Exit codes: 2 (parsing), 3 (fichier introuvable).
- Tests: ajout cas limites (fence non fermé, NFD, n=1 MAD, n=2 quantiles, neutralisations).
